## CARREGANDO PACOTES ##
library(vroom)
library(survey)
library(dplyr)
library(writexl)

## CARREGANDO DADOS ##

pense <- vroom("PENSE2019_MICRODADOS.csv")

## CALCULO USANDO PACOTE ##

# Ajuste necessario para calculo correto dos erros
options(survey.lonely.psu = "adjust")

# Populacao de interesse
pense$Alvo <- ifelse(((pense$B01003!=1 & pense$B01003!=4)
                     | is.na(pense$B01003)),
                     1, 0) #13 a 17 anos

# Objeto inicial
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)

# Aplica a pos-estratificacao -- este é o objeto final
desenho_pense <- postStratify(desenho_pre,
                              strata = ~POSEST,
                              population = pense[,
                                                 c("POSEST",
                                                   "TOTAIS_POSEST")])

# O dominio de estimacao é IND_EXPANSAO = 1, entao ja pode deixar criado o objeto
desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)
desenho_validos <- subset(desenho_validos, Alvo==1) #tira <13 e >=18 anos

# Exemplo de calculo dos totais por UF
totais_UF <- svytotal(~as.factor(UF), desenho_validos)

## TABELA 1.1.1 ##

#olhando as categorias das variaveis de interesse
table(pense$B01003) #idade
table(pense$REGIAO) #regiao
table(pense$B01001A) #sexo
table(pense$DEP_ADMIN) #dep adm

## DEFININDO FUNCOES

estima_total <- function(dados, desenhos, nomes_vars){
  variaveis <- list()
  for (i in 1:length(nomes_vars)){
    variaveis[[i]] <- as.factor(unlist(dados[nomes_vars[i]]))
  }
  tabela <- svytotal(~do.call(interaction, variaveis), desenhos,
                     na.rm=T)
  ic <- confint(tabela) #intervalos de confianca
  tabela <- as.data.frame(tabela)
  tabela <- cbind(tabela, ic) #juntando
  return(tabela)
}

arruma_tab <- function(tabela, indicador, nome_var){
  tabela$Indicador <- indicador
  tabela$Variavel <- nome_var
  row.names(tabela) <- NULL
  tabela <- tabela%>%
    rename(Total=total, Erro_Padrao=SE, LI=`2.5 %`, LS=`97.5 %`)
  return(tabela)
}

## SEXO - por idade e região

tt1 <- estima_total(pense, desenho_validos,
                   c("B01001A", "B01003"))
tt2 <- estima_total(pense, desenho_validos,
                   c("REGIAO", "B01001A", "B01003"))
#total de combinacoes das 2 variaveis: 15
#total de combinacoes das 3 variaveis: 75

#existem 5 faixas etarias, so queremos a 2a e a 3a
tt1 <- tt1[4:9, ]
tt2 <- tt2[16:45, ]

#existem 3 categorias de sexo, so queremos as 2 primeiras
tt1 <- tt1[c(1:2, 4:5), ]
tt2 <- tt2[c(1:10, 16:25), ]

#criando demais colunas
tt1$Idade <- rep(c("13 a 15 anos", "16 e 17 anos"), each=2)
tt1$Localizacao <- rep("Brasil", 4)
tt1$Valor_Var <- rep(c("Masculino", "Feminino"), 2)

tt2$Idade <- rep(c("13 a 15 anos", "16 e 17 anos"), each=10)
tt2$Localizacao <- rep(c("Norte", "Nordeste", "Sudeste", "Sul",
                   "Centro-Oeste"), 4)
tt2$Valor_Var <- rep(rep(c("Masculino", "Feminino"), each=5), 2)

#arrumando a tabela
tt1 <- arruma_tab(tt1, "Total de escolares", "Sexo")
tt1 <- tt1%>%
  select(Indicador, Idade, Localizacao, Variavel, Valor_Var, Total,
         Erro_Padrao, LI, LS)
tt2 <- arruma_tab(tt2, "Total de escolares", "Sexo")
tt2 <- tt2%>%
  select(Indicador, Idade, Localizacao, Variavel, Valor_Var, Total,
         Erro_Padrao, LI, LS)

#Juntando tabelas
tt3 <- rbind(tt1[1, ], tt2[1:5, ], tt1[2, ], tt2[6:10, ], tt1[3, ],
             tt2[11:15, ], tt1[4, ], tt2[16:20, ])

## SEXO - por regiao, para escolares de 13 a 17 anos

tt4 <- estima_total(pense, desenho_validos, "B01001A")
tt5 <- estima_total(pense, desenho_validos, c("REGIAO", "B01001A"))

#total de combinacoes das 2 variaveis: 15

#existem 3 categorias de sexo, so queremos as 2 primeiras
tt4 <- tt4[1:2, ]
tt5 <- tt5[1:10, ]

#criando demais colunas
tt4$Idade <- "13 a 17 anos"
tt4$Localizacao <- rep("Brasil", 2)
tt4$Valor_Var <- c("Masculino", "Feminino")

tt5$Idade <- "13 a 17 anos"
tt5$Localizacao <- rep(c("Norte", "Nordeste", "Sudeste",
                             "Sul", "Centro-Oeste"), 2)
tt5$Valor_Var <- rep(c("Masculino", "Feminino"), each=5)

#arrumando a tabela
tt4 <- arruma_tab(tt4, "Total de escolares", "Sexo")
tt4 <- tt4%>%
  select(Indicador, Idade, Localizacao, Variavel, Valor_Var, Total,
         Erro_Padrao, LI, LS)

tt5 <- arruma_tab(tt5, "Total de escolares", "Sexo")
tt5 <- tt5%>%
  select(Indicador, Idade, Localizacao, Variavel, Valor_Var, Total,
         Erro_Padrao, LI, LS)

#juntando tabelas
tt6 <- rbind(tt4[1, ], tt5[1:5, ], tt4[2, ], tt5[6:10, ])

#juntando o grupo de 13 a 17 anos a saida
tt7 <- rbind(tt6, tt3)

## DEP ADM - por idade e regiao

tt8 <- estima_total(pense, desenho_validos,
                    c("DEP_ADMIN", "B01003"))
tt9 <- estima_total(pense, desenho_validos,
                    c("REGIAO", "DEP_ADMIN", "B01003"))
#total de combinacoes das 2 variaveis: 10
#total de combinacoes das 3 variaveis: 50

#existem 5 faixas etarias, so queremos a 2a e a 3a
tt8 <- tt8[3:6, ]
tt9 <- tt9[11:30, ]

#criando demais colunas
tt8$Idade <- rep(c("13 a 15 anos", "16 e 17 anos"), each=2)
tt8$Localizacao <- rep("Brasil", 2)
tt8$Valor_Var <- rep(c("Pública", "Privada"), 2)

tt9$Idade <- rep(c("13 a 15 anos", "16 e 17 anos"), each=10)
tt9$Localizacao <- rep(c("Norte", "Nordeste", "Sudeste", "Sul", "Centro-Oeste"), 4)
tt9$Valor_Var <- rep(rep(c("Pública", "Privada"), each=5), 2)

#arrumando a tabela
tt8 <- arruma_tab(tt8, "Total de escolares", "Dep Adm")
tt8 <- tt8%>%
  select(Indicador, Idade, Localizacao, Variavel, Valor_Var,
         Total, Erro_Padrao, LI, LS)

tt9 <- arruma_tab(tt9, "Total de escolares", "Dep Adm")
tt9 <- tt9%>%
  select(Indicador, Idade, Localizacao, Variavel, Valor_Var,
         Total, Erro_Padrao, LI, LS)

#juntando tabelas
tt10 <- rbind(tt8[1, ], tt9[1:5, ], tt8[2, ], tt9[6:10, ],
              tt8[3, ], tt9[11:15, ], tt8[4, ], tt9[16:20, ])

## DEP ADM - por regiao, para escolares de 13 a 17 anos

tt11 <- estima_total(pense, desenho_validos, "DEP_ADMIN")
tt12 <- estima_total(pense, desenho_validos,
                    c("REGIAO", "DEP_ADMIN"))

#total de combinacoes das 2 variaveis: 10

#criando demais colunas
tt11$Idade <- "13 a 17 anos"
tt11$Localizacao <- rep("Brasil", 2)
tt11$Valor_Var <- c("Pública", "Privada")

tt12$Idade <- "13 a 17 anos"
tt12$Localizacao <- rep(c("Norte", "Nordeste", "Sudeste", "Sul",
                    "Centro-Oeste"), 2)
tt12$Valor_Var <- rep(c("Pública", "Privada"), each=5)

#arrumando a tabela
tt11 <- arruma_tab(tt11, "Total de escolares", "Dep Adm")
tt11 <- tt11%>%
  select(Indicador, Idade, Localizacao, Variavel, Valor_Var, Total,
         Erro_Padrao, LI, LS)

tt12 <- arruma_tab(tt12, "Total de escolares", "Dep Adm")
tt12 <- tt12%>%
  select(Indicador, Idade, Localizacao, Variavel, Valor_Var, Total,
         Erro_Padrao, LI, LS)

#juntando tabelas
tt13 <- rbind(tt11[1, ], tt12[1:5, ], tt11[2, ], tt12[6:10, ])

#juntando o grupo de 13 a 17 anos a saida
tt14 <- rbind(tt13, tt10)

## JUNTANDO SEXO E DEP ADM

tabela_111 <- rbind(tt7, tt14)
write_xlsx(list("1.1.1" = tabela_111), "Tema01/Tema01.xlsx")

#pesquisar sobre expansao da amostra