### ANO ESCOLAR - tira sem resposta ###

## IDADE - TODAS ##

# IND_EXPANSAO - TODOS #

#TESTE 1

pense$Alvo <- ifelse((pense$B01021A %in% c(-2, 1:7))
                     | (is.na(pense$B01021A)), 1, 0)
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)
desenho_pense <- postStratify(desenho_pre,
                              strata = ~POSEST,
                              population = pense[,
                                                 c("POSEST",
                                                   "TOTAIS_POSEST")])
#desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)
svytotal(~as.factor(REGIAO), desenho_pense)
#Norte = 1651920 >

# IND_EXPANSAO - tira 0 #

#TESTE 2

pense$Alvo <- ifelse((pense$B01021A %in% c(-2, 1:7))
                     | (is.na(pense$B01021A)), 1, 0)
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)
desenho_pense <- postStratify(desenho_pre,
                              strata = ~POSEST,
                              population = pense[,
                                                 c("POSEST",
                                                   "TOTAIS_POSEST")])
desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)
svytotal(~as.factor(REGIAO), desenho_validos)
#Norte = 1589361 >

## IDADE - tira <13 anos e >=18 anos ##

#IND_EXPANSAO - TODOS #

#TESTE 3

pense$Alvo <- ifelse(((pense$B01021A %in% c(-2, 1:7))
                      | (is.na(pense$B01021A)))
                     & ((pense$B01003 %in% c(2, 3, 9))
                        | (is.na(pense$B01003))), 1, 0)
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)
desenho_pense <- postStratify(desenho_pre,
                              strata = ~POSEST,
                              population = pense[,
                                                 c("POSEST",
                                                   "TOTAIS_POSEST")])
#desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)
svytotal(~as.factor(REGIAO), subset(desenho_pense, Alvo==1))
#Norte = 1348164 >

#TESTE 4

# IND_EXPANSAO - tira 0 #

pense$Alvo <- ifelse(((pense$B01021A %in% c(-2, 1:7))
                      | (is.na(pense$B01021A)))
                     & ((pense$B01003 %in% c(2, 3, 9))
                        | (is.na(pense$B01003))), 1, 0)
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)
desenho_pense <- postStratify(desenho_pre,
                              strata = ~POSEST,
                              population = pense[,
                                                 c("POSEST",
                                                   "TOTAIS_POSEST")])
desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)
svytotal(~as.factor(REGIAO), subset(desenho_validos, Alvo==1))
#Norte = 1285604 >

## IDADE - tira sem resposta ##

# IND_EXPANSAO - TODOS #

#TESTE 5

pense$Alvo <- ifelse(((pense$B01021A %in% c(-2, 1:7))
                      | (is.na(pense$B01021A)))
                     & ((pense$B01003 %in% 1:4)
                        | (is.na(pense$B01003))), 1, 0)
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)
desenho_pense <- postStratify(desenho_pre,
                              strata = ~POSEST,
                              population = pense[,
                                                 c("POSEST",
                                                   "TOTAIS_POSEST")])
#desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)
svytotal(~as.factor(REGIAO), subset(desenho_pense, Alvo==1))
#Norte = 1647758 >

# IND_EXPANSAO - tira 0 #

#TESTE 6

pense$Alvo <- ifelse(((pense$B01021A %in% c(-2, 1:7))
                      | (is.na(pense$B01021A)))
                     & ((pense$B01003 %in% 1:4)
                        | (is.na(pense$B01003))), 1, 0)
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)
desenho_pense <- postStratify(desenho_pre,
                              strata = ~POSEST,
                              population = pense[,
                                                 c("POSEST",
                                                   "TOTAIS_POSEST")])
desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)
svytotal(~as.factor(REGIAO), subset(desenho_validos, Alvo==1))
#Norte = 1585199 >

## IDADE - tira <13, >=18 e sem resposta ##

# IND_EXPANSAO - TODOS #

#TESTE 7

pense$Alvo <- ifelse(((pense$B01021A %in% c(-2, 1:7))
                      | (is.na(pense$B01021A))) & ((pense$B01003 %in% c(2, 3))
                                                   | (is.na(pense$B01003))), 1, 0)
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)
desenho_pense <- postStratify(desenho_pre,
                              strata = ~POSEST,
                              population = pense[,
                                                 c("POSEST",
                                                   "TOTAIS_POSEST")])
#desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)
svytotal(~as.factor(REGIAO), subset(desenho_pense, Alvo==1))
#Norte = 1344924 >

# IND_EXPANSAO - tira 0 #

#TESTE 8

pense$Alvo <- ifelse(((pense$B01021A %in% c(-2, 1:7))
                      | (is.na(pense$B01021A))) & ((pense$B01003 %in% c(2, 3))
                                                   | (is.na(pense$B01003))), 1, 0)
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)
desenho_pense <- postStratify(desenho_pre,
                              strata = ~POSEST,
                              population = pense[,
                                                 c("POSEST",
                                                   "TOTAIS_POSEST")])
desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)
svytotal(~as.factor(REGIAO), subset(desenho_validos, Alvo==1))
#Norte = 1282365 <