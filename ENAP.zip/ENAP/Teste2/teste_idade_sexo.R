## IDADE - inclui nao resposta ##

# SEXO - inclui nao resposta #

#TESTE 1

pense$Alvo <- ifelse((pense$B01003 %in% c(2, 3, 9))
                      | (is.na(pense$B01003)), 1, 0)
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)
desenho_pense <- postStratify(desenho_pre,
                              strata = ~POSEST,
                              population = pense[,
                                                 c("POSEST",
                                                   "TOTAIS_POSEST")])
desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)
desenho_validos <- subset(desenho_validos, Alvo==1)
svytotal(~as.factor(REGIAO), desenho_validos, na.rm=T)
#Norte = 1285936 >

# SEXO - tira nao resposta #

#TESTE 2

pense$Alvo <- ifelse(((pense$B01003 %in% c(2, 3, 9))
                       | (is.na(pense$B01003)))
                     & ((pense$B01001A %in% 1:2)
                        | (is.na(pense$B01001A))), 1, 0)
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)
desenho_pense <- postStratify(desenho_pre,
                              strata = ~POSEST,
                              population = pense[,
                                                 c("POSEST",
                                                   "TOTAIS_POSEST")])
desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)
desenho_validos <- subset(desenho_validos, Alvo==1)
svytotal(~as.factor(REGIAO), desenho_validos, na.rm=T)
#Norte = 1284016 >

## IDADE - tira nao resposta ##

# SEXO - inclui nao resposta #

#TESTE 3

pense$Alvo <- ifelse((pense$B01003 %in% c(2, 3))
                      | (is.na(pense$B01003)), 1, 0)
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)
desenho_pense <- postStratify(desenho_pre,
                              strata = ~POSEST,
                              population = pense[,
                                                 c("POSEST",
                                                   "TOTAIS_POSEST")])
desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)
desenho_validos <- subset(desenho_validos, Alvo==1)
svytotal(~as.factor(REGIAO), desenho_validos, na.rm=T)
#Norte = 1282681 >

# SEXO - tira nao resposta

#TESTE 4

pense$Alvo <- ifelse(((pense$B01003 %in% c(2, 3))
                      | (is.na(pense$B01003)))
                     & ((pense$B01001A %in% 1:2)
                        | (is.na(pense$B01001A))), 1, 0)
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)
desenho_pense <- postStratify(desenho_pre,
                              strata = ~POSEST,
                              population = pense[,
                                                 c("POSEST",
                                                   "TOTAIS_POSEST")])
desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)
desenho_validos <- subset(desenho_validos, Alvo==1)
svytotal(~as.factor(REGIAO), desenho_validos, na.rm=T)
#Norte = 1281133 >