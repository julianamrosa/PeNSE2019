## TABELA 1.1.2 ##

#vetor de capitais
caps <- c("Porto Velho", "Rio Branco", "Manaus", "Boa Vista",
          "Belém", "Macapá", "Palmas", "São Luís", "Teresina",
          "Fortaleza", "Natal", "João Pessoa", "Recife", "Maceió",
          "Aracaju", "Salvador", "Belo Horizonte", "Vitória",
          "Rio de Janeiro", "São Paulo", "Curitiba",
          "Florianópolis", "Porto Alegre", "Campo Grande",
          "Cuiabá", "Goiânia", "Brasília")

#olhando categorias
table(pense$MUNICIPIO_CAP) #capitais

## SEXO - por capital

tt1 <- estima_total(pense, desenho_validos,
                    c("MUNICIPIO_CAP", "B01001A"))
#total de combinacoes: 84

#existem 29 categorias de capitais, temos que descartar a primeira
tt1 <- tt1[c(2:28, 30:56, 58:84), ]

#existem 3 categorias de sexo, so queremos as 2 primeiras
tt1 <- tt1[1:54, ]

#criando demais colunas
tt1$Localizacao <- rep(caps, 2)
tt1$Valor_Var <- rep(c("Masculino", "Feminino"), each=27)

#arrumando a tabela
tt1 <- arruma_tab(tt1, "Total de escolares",
                           "Sexo")
tt1 <- tt1%>%
  select(Indicador, Localizacao, Variavel, Valor_Var, Total,
         Erro_Padrao, LI, LS)

## DEP ADM - por capital

tt2 <- estima_total(pense, desenho_validos,
                    c("MUNICIPIO_CAP", "DEP_ADMIN"))
#total de combinacoes: 56

#existem 29 categorias de capitais, temos que descartar a primeira
tt2 <- tt2[c(2:28, 30:56), ]

#criando demais colunas
tt2$Localizacao <- rep(caps, 2)
tt2$Valor_Var <- rep(c("Pública", "Privada"), each=27)

#arrumando a tabela
tt2 <- arruma_tab(tt2, "Total de escolares",
                  "Dep Adm")
tt2 <- tt2%>%
  select(Indicador, Localizacao, Variavel, Valor_Var, Total,
         Erro_Padrao, LI, LS)

## JUNTANDO SEXO E DEP ADM

tabela_113 <- rbind(tt1, tt2)
write_xlsx(list("1.1.1" = tabela_111, "1.1.2" = tabela_112, "1.1.3" = tabela_113), "Tema01/Tema01.xlsx")
