## CARREGANDO DADOS ##

setwd("C:/Users/Juliana Rosa/OneDrive/Documents/ENAP") #trocar path
pense <- read.csv("PENSE2019_MICRODADOS.csv")

## CARREGANDO PACOTES ##
library(survey)
library(dplyr)
library(writexl)

## CALCULO USANDO PACOTE ##

# Ajuste necessario para calculo correto dos erros
options(survey.lonely.psu = "adjust")

# Populacao de interesse
pense$Alvo <- ifelse(pense$B01003 %in% 2:3, 1, 0) #13 a 17 anos

# Objeto inicial
desenho_pre <- svydesign(
  ids = ~ESCOLA,
  strata = ~ESTRATO,
  weights = ~PESO_INICIAL,
  nest = TRUE,
  data = pense)

# Aplica a pos-estratificacao -- este é o objeto final
desenho_pense <- postStratify(desenho_pre, strata = ~POSEST, population = pense[,c("POSEST","TOTAIS_POSEST")])

# O dominio de estimacao é IND_EXPANSAO = 1, entao ja pode deixar criado o objeto
desenho_validos <- subset(desenho_pense, IND_EXPANSAO == 1)

# Exemplo de calculo dos totais por UF
totais_UF <- svytotal(~as.factor(UF), desenho_validos)

## TABELA 1.1.1 ##

#olhando as categorias das variaveis de interesse
table(pense$B01003) #idade
table(pense$REGIAO) #regiao
table(pense$B01001A) #sexo
table(pense$DEP_ADMIN) #dep adm

## SEXO - por idade e região

tabela_111_sexo <- svytotal(~interaction(as.factor(REGIAO),
                                         as.factor(B01001A),
                                         as.factor(B01003)),
                       desenho_validos, na.rm=T) #estimativas pontuais

ic <- confint(tabela_111_sexo) #intervalos de confianca
tabela_111_sexo <- as.data.frame(tabela_111_sexo)
tabela_111_sexo <- cbind(tabela_111_sexo, ic) #juntando
#total de combinacoes das 3 variaveis: 75

#existem 5 faixas etarias, so queremos a 2a e a 3a
tabela_111_sexo <- tabela_111_sexo[16:45, ]

#existem 3 categorias de sexo, so queremos as 2 primeiras
tabela_111_sexo <- tabela_111_sexo[c(1:10, 16:25), ]

#criando demais colunas
tabela_111_sexo$Indicador <- "Total de escolares"
tabela_111_sexo$Idade <- rep(c("13 a 15 anos", "16 e 17 anos"), each=10)
tabela_111_sexo$Regiao <- rep(c("Norte", "Nordeste", "Sudeste", "Sul", "Centro-Oeste"), 4)
tabela_111_sexo$Variavel <- "Sexo"
tabela_111_sexo$Valor_Var <- rep(rep(c("Masculino", "Feminino"), each=5), 2)

#arrumando a tabela
row.names(tabela_111_sexo) <- NULL
tabela_111_sexo <- tabela_111_sexo%>%
  rename(Total=total, Erro_Padrao=SE, LI=`2.5 %`, LS=`97.5 %`)%>%
  select(Indicador, Idade, Regiao, Variavel, Valor_Var, Total, Erro_Padrao, LI, LS)

## SEXO - por regiao, para escolares de 13 a 17 anos

tabela_13a17 <- svytotal(~interaction(as.factor(REGIAO),
                                      as.factor(B01001A),
                                      as.factor(Alvo)),
                         desenho_validos, na.rm=T) #estimativas pontuais

ic <- confint(tabela_13a17) #intervalos de confianca
tabela_13a17 <- as.data.frame(tabela_13a17)
tabela_13a17 <- cbind(tabela_13a17, ic) #juntando
#total de combinacoes das 3 variaveis: 30

#so queremos a populacao alvo
tabela_13a17 <- tabela_13a17[16:30, ]

#existem 3 categorias de sexo, so queremos as 2 primeiras
tabela_13a17 <- tabela_13a17[1:10, ]

#criando demais colunas
tabela_13a17$Indicador <- "Total de escolares"
tabela_13a17$Idade <- "13 a 17 anos"
tabela_13a17$Regiao <- rep(c("Norte", "Nordeste", "Sudeste", "Sul", "Centro-Oeste"), 2)
tabela_13a17$Variavel <- "Sexo"
tabela_13a17$Valor_Var <- rep(c("Masculino", "Feminino"), each=5)

#arrumando a tabela
row.names(tabela_13a17) <- NULL
tabela_13a17 <- tabela_13a17%>%
  rename(Total=total, Erro_Padrao=SE, LI=`2.5 %`, LS=`97.5 %`)%>%
  select(Indicador, Idade, Regiao, Variavel, Valor_Var, Total, Erro_Padrao, LI, LS)

#juntando o grupo de 13 a 17 anos a saida
tabela_111_sexo <- rbind(tabela_13a17, tabela_111_sexo)

## DEP ADM - por idade e regiao

tabela_111_depadm <- svytotal(~interaction(as.factor(REGIAO),
                                           as.factor(DEP_ADMIN),
                                         as.factor(B01003)),
                            desenho_validos, na.rm=T) #estimativas pontuais

ic <- confint(tabela_111_depadm) #intervalos de confianca
tabela_111_depadm <- as.data.frame(tabela_111_depadm)
tabela_111_depadm <- cbind(tabela_111_depadm, ic) #juntando
#total de combinacoes das 3 variaveis: 50

#existem 5 faixas etarias, so queremos a 2a e a 3a
tabela_111_depadm <- tabela_111_depadm[11:30, ]

#criando demais colunas
tabela_111_depadm$Indicador <- "Total de escolares"
tabela_111_depadm$Idade <- rep(c("13 a 15 anos", "16 e 17 anos"), each=10)
tabela_111_depadm$Regiao <- rep(c("Norte", "Nordeste", "Sudeste", "Sul", "Centro-Oeste"), 4)
tabela_111_depadm$Variavel <- "Dep Adm"
tabela_111_depadm$Valor_Var <- rep(rep(c("Pública", "Privada"), each=5), 2)

#arrumando a tabela
row.names(tabela_111_depadm) <- NULL
tabela_111_depadm <- tabela_111_depadm%>%
  rename(Total=total, Erro_Padrao=SE, LI=`2.5 %`, LS=`97.5 %`)%>%
  select(Indicador, Idade, Regiao, Variavel, Valor_Var, Total, Erro_Padrao, LI, LS)

## DEP ADM - por regiao, para escolares de 13 a 17 anos

tabela_13a17 <- svytotal(~interaction(as.factor(REGIAO),
                                      as.factor(DEP_ADMIN),
                                      as.factor(Alvo)),
                         desenho_validos, na.rm=T) #estimativas pontuais
ic <- confint(tabela_13a17) #intervalos de confianca
tabela_13a17 <- as.data.frame(tabela_13a17)
tabela_13a17 <- cbind(tabela_13a17, ic) #juntando
#total de combinacoes das 3 variaveis: 30

#so queremos a populacao alvo
tabela_13a17 <- tabela_13a17[11:20, ]

#criando demais colunas
tabela_13a17$Indicador <- "Total de escolares"
tabela_13a17$Idade <- "13 a 17 anos"
tabela_13a17$Regiao <- rep(c("Norte", "Nordeste", "Sudeste", "Sul", "Centro-Oeste"), 2)
tabela_13a17$Variavel <- "Dep Adm"
tabela_13a17$Valor_Var <- rep(c("Pública", "Privada"), each=5)

#arrumando a tabela
row.names(tabela_13a17) <- NULL
tabela_13a17 <- tabela_13a17%>%
  rename(Total=total, Erro_Padrao=SE, LI=`2.5 %`, LS=`97.5 %`)%>%
  select(Indicador, Idade, Regiao, Variavel, Valor_Var, Total, Erro_Padrao, LI, LS)

#juntando o grupo de 13 a 17 anos a saida
tabela_111_depadm <- rbind(tabela_13a17, tabela_111_depadm)

## JUNTANDO SEXO E DEP ADM

tabela_111 <- rbind(tabela_111_sexo, tabela_111_depadm)
write_xlsx(tabela_111, "tabela_111R.xlsx")

#desenhar plano amostral
#tentar adaptar as formulas de amostragem
#aplicar para tabela 1.1.2