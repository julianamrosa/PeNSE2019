## TABELA 1.1.2 ##

#vetor de ufs
ufs <- c("Rondônia", "Acre", "Amazonas", "Roraima", "Pará",
         "Amapá", "Tocantins", "Maranhão", "Piauí", "Ceará",
         "Rio Grande do Norte", "Paraíba", "Pernambuco",
         "Alagoas", "Sergipe", "Bahia", "Minas Gerais",
         "Espírito Santo", "Rio de Janeiro", "São Paulo",
         "Paraná", "Santa Catarina", "Rio Grande do Sul",
         "Mato Grosso do Sul", "Mato Grosso",  "Goiás",
         "Distrito Federal")

#olhando categorias
table(pense$UF) #uf

## SEXO - por UF e região

tt1 <- estima_total(pense, desenho_validos,
                    c("B01001A")) #Brasil
tt2 <- estima_total(pense, desenho_validos,
                    c("REGIAO", "B01001A")) #Regioes
tt3 <- estima_total(pense, desenho_validos,
                    c("UF", "B01001A")) #UFs
#total de combinacoes Brasil: 3
#total de combinacoes Regioes: 15
#total de combinacoes UFs: 81

#existem 3 categorias de sexo, so queremos as 2 primeiras
tt1 <- tt1[1:2, ]
tt2 <- tt2[1:10, ]
tt3 <- tt3[1:54, ]

#criando demais colunas
tt1$Localizacao <- rep("Brasil", 2)
tt1$Valor_Var <- c("Masculino", "Feminino")

tt2$Localizacao <- rep(c("Norte", "Nordeste", "Sudeste", "Sul",
                         "Centro-Oeste"), 2)
tt2$Valor_Var <- rep(c("Masculino", "Feminino"), each=5)

tt3$Localizacao <- ufs
tt3$Valor_Var <- rep(c("Masculino", "Feminino"), each=27)

#arrumando a tabela
tabelas <- list(tt1, tt2, tt3)
for (i in 1:length(tabelas)){
  tabelas[[i]] <- arruma_tab(tabelas[[i]], "Total de escolares",
                             "Sexo")
  tabelas[[i]] <- tabelas[[i]]%>%
    select(Indicador, Localizacao, Variavel, Valor_Var, Total,
           Erro_Padrao, LI, LS)
  tab <- paste("tt", i, sep="")
  assign(tab, tabelas[[i]])
}

#Juntando tabelas
tt4 <- rbind(tt1[1, ], tt2[1, ], tt3[1:7, ], tt2[2, ], tt3[8:16, ],
             tt2[3, ], tt3[17:20, ], tt2[4, ], tt3[21:23, ],
             tt2[5, ], tt3[24:27, ], tt1[2, ], tt2[6, ], tt3[28:34, ],
             tt2[7, ], tt3[35:43, ], tt2[8, ], tt3[44:47, ], tt2[9, ],
             tt3[48:50, ], tt2[10, ], tt3[51:54, ])

## DEP ADM - por UF e região

tt1 <- estima_total(pense, desenho_validos,
                    c("DEP_ADMIN")) #Brasil
tt2 <- estima_total(pense, desenho_validos,
                    c("REGIAO", "DEP_ADMIN")) #Regioes
tt3 <- estima_total(pense, desenho_validos,
                    c("UF", "DEP_ADMIN")) #UFs
#total de combinacoes Brasil: 2
#total de combinacoes Regioes: 10
#total de combinacoes UFs: 54

#criando demais colunas
tt1$Localizacao <- rep("Brasil", 2)
tt1$Valor_Var <- c("Pública", "Privada")

tt2$Localizacao <- rep(c("Norte", "Nordeste", "Sudeste", "Sul",
                         "Centro-Oeste"), 2)
tt2$Valor_Var <- rep(c("Pública", "Privada"), each=5)

tt3$Localizacao <- ufs
tt3$Valor_Var <- rep(c("Pública", "Privada"), each=27)

#arrumando a tabela
tabelas <- list(tt1, tt2, tt3)
for (i in 1:length(tabelas)){
  tabelas[[i]] <- arruma_tab(tabelas[[i]], "Total de escolares",
                             "Dep Adm")
  tabelas[[i]] <- tabelas[[i]]%>%
    select(Indicador, Localizacao, Variavel, Valor_Var, Total,
           Erro_Padrao, LI, LS)
  tab <- paste("tt", i, sep="")
  assign(tab, tabelas[[i]])
}

#Juntando tabelas
tt5 <- rbind(tt1[1, ], tt2[1, ], tt3[1:7, ], tt2[2, ], tt3[8:16, ],
             tt2[3, ], tt3[17:20, ], tt2[4, ], tt3[21:23, ],
             tt2[5, ], tt3[24:27, ], tt1[2, ], tt2[6, ], tt3[28:34, ],
             tt2[7, ], tt3[35:43, ], tt2[8, ], tt3[44:47, ], tt2[9, ],
             tt3[48:50, ], tt2[10, ], tt3[51:54, ])

## JUNTANDO SEXO E DEP ADM

tabela_112 <- rbind(tt4, tt5)
write_xlsx(list("1.1.1" = tabela_111, "1.1.2" = tabela_112), "Tema01/Tema01.xlsx")
